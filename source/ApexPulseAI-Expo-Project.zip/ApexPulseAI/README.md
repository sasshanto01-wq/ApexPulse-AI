# ApexPulse AI

A mobile-first Expo / React Native starter for an AI-assisted trading analysis app.

## Run on Android or iOS

1. Install Node.js and Expo Go on your phone.
2. In this folder run `npm install`.
3. Run `npx expo start`.
4. Scan the QR code with Expo Go (Android) or the Camera app (iOS).

## Included

- Dark, orange-accented mobile UI inspired by the supplied screen recording.
- Dashboard, Watchlist, Analyze, History and Profile tabs.
- Forex, crypto, stock and index sample instruments.
- Interactive timeframe/instrument selection and sample candle chart.
- Screenshot selection using the device photo library.
- Clearly labeled demo signal cards with bias, confidence, entry, stop loss, take profit, support and resistance.
- Demo email/password form and risk preference controls.

## Important implementation status

- **Market data:** SAMPLE / simulated only. No live exchange feed is connected.
- **AI:** GPT 5.6 Terra is the intended provider, but no provider endpoint or credentials were supplied. The current app intentionally uses a transparent demo result and does not claim that a real model analyzed the screenshot.
- **Authentication:** The current sign-in form is a local UI demonstration, not production authentication.
- **Trading:** No broker connection, order placement or auto-trading exists.

## Connecting GPT 5.6 Terra safely

Do not place provider API keys in the Expo app. Add a backend service, store `GPT_PROVIDER_BASE_URL`, `GPT_PROVIDER_API_KEY`, and `GPT_PROVIDER_MODEL` as server-side secrets, and expose an authenticated analysis endpoint. The endpoint should accept the selected symbol, timeframe and uploaded image, call the provider's documented vision-capable API, validate the structured response, and return the signal fields. The exact provider endpoint and authentication format must be confirmed from the provider documentation before enabling it.

## Connecting real market data

Replace the sample `markets` data in `App.tsx` with a backend market-data adapter. Until then, keep the SAMPLE labels visible and do not present simulated prices as live quotes.

## Risk notice

Predictions are probabilistic analysis, not guaranteed outcomes or financial advice. Sample values are illustrative only. The app does not execute trades.
